#!/bin/bash

docker run -itd -p 80:3000 mondadori89/app-dcw5:develop