#!/bin/bash

docker rm -f $(docker ps -qa) || true
docker rmi mondadori89/app-dcw5:develop || true
